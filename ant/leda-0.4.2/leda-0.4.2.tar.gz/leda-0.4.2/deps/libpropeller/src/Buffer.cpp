//
//	File: Buffer.cpp
//	Dynamic buffer
//	
/*
Copyright 2010 Sergey Zavadski

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
 */

#include "Buffer.h"
#include "common.h"


#define BUFFER_CHUNK_LENGTH 0x1000

#define BUFFER_MAX_LENGTH 1024 * 1024 * 2

Buffer::Buffer( )
: m_chunkLength( BUFFER_CHUNK_LENGTH ), m_bufferLength( 0 ), m_buffer( NULL ), m_contentLength( 0 ), m_contentOffset( 0 ) 
{
}

Buffer::~Buffer( )
{
    if ( m_buffer )
    {
        free( m_buffer );
    }
}

void Buffer::append( const char* buffer, unsigned int bufferLength )
{
    //
    //	total length of contained content
    //
    unsigned int totalLength = m_contentLength + m_contentOffset;

    //
    //	bytes remaining in the buffer
    //
    unsigned int remainingLength = m_bufferLength - totalLength;

    //
    //	extend buffer in chunks of m_chunksize if not big enough to contain new data
    //
    if ( remainingLength <= bufferLength )
    {
        unsigned int lengthNeeded = bufferLength + totalLength;

        m_bufferLength = lengthNeeded / m_chunkLength;
        m_bufferLength *= m_chunkLength;

        //
        //	allocate memory
        //
        while ( m_bufferLength <= lengthNeeded )
        {
            m_bufferLength += m_chunkLength;
        }

        //
        //	allocate buffer
        //
        m_buffer = ( char* ) realloc( m_buffer, m_bufferLength );
    }

    char* targetBuffer = m_buffer + totalLength;

    if ( buffer )
    {
        memcpy( targetBuffer, buffer, bufferLength );

        m_contentLength += bufferLength;
    }

}

char* Buffer::getBuffer( unsigned int length )
{
    //
    //  make sure there is enough space 
    //
    append( NULL, length );

    char* buffer = m_buffer + m_contentOffset + m_contentLength;

    return buffer;
}

void Buffer::shrink( unsigned int offset )
{
    if ( m_contentLength >= offset )
    {
        m_contentLength -= offset;
        m_contentOffset += offset;
    }

    if ( !m_contentLength )
    {
        m_contentOffset = 0;

        //
        //	reset to original size if needed
        //
        reallocate( );
    }
}

void Buffer::setBufferLength( unsigned int bufferLength )
{
    m_contentLength += bufferLength;
}

void Buffer::clear( )
{
    m_contentLength = 0;
    m_contentOffset = 0;

    //
    //	reset internal buffer to original size needed
    //
    reallocate( );

}

void Buffer::reallocate( )
{
    if ( m_bufferLength > BUFFER_MAX_LENGTH )
    {
        m_bufferLength = m_chunkLength;
        m_buffer = ( char* ) realloc( m_buffer, m_bufferLength );
    }
}

