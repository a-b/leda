/*
Copyright 2012-2014 Sergey Zavadski

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
 */
#include "event.h"

#include "trace.h"


    
namespace libevent
{
    static bool s_initThreads = false;

    void General::setSocketNonBlocking( const sys::Socket& socket )
    {
        evutil_make_socket_nonblocking( socket );
    }

    void General::initThreads()
    {
        if ( s_initThreads )
        {
            return;
        }

        s_initThreads = true;
            
#ifdef WIN32
     evthread_use_windows_threads();
#else
     evthread_use_pthreads();
#endif
    }
    
    void General::shutdown()
    {
        libevent_global_shutdown();
    }

    void General::init( )
    {
#ifdef _USE_SSL
        TRACE( "initializing openssl", "" );
        //
        //  init openssl
        //
        OpenSSL_add_ssl_algorithms( );
        ERR_load_crypto_strings( );
        SSL_load_error_strings( );
        OpenSSL_add_all_algorithms( );

#endif
    }
    

    Base::Base( )
    : m_base( NULL )
    {
        m_base = event_base_new( );

        evthread_make_base_notifiable( m_base );
    }
    void Base::start(  )
    {
        TRACE_ENTERLEAVE();
            
        event_base_loop( m_base, EVLOOP_NO_EXIT_ON_EMPTY );
    }
    
    void Base::stop( ) const
    {
        TRACE_ENTERLEAVE( );

        if ( m_base )
        {
            event_base_loopbreak( m_base );
        }

    }
    
    Base::~Base( )
    {
        TRACE_ENTERLEAVE();
        stop( );
        
    // this segfaults when in server mode since we do  not store connection pointers and therefore cannot remove them from event base. leaking memory here
//        if ( m_base )
//        {
//            event_base_free( m_base );
//        }
//        
        m_base = NULL;
    }

    Listener::Listener( sys::Socket::Type type )
    : m_listenerEvent( NULL ), m_port( 0 ), m_host( "" ), m_socket( type )
    {
    }

    void Listener::listen( const Base& base)
    {
        TRACE_ENTERLEAVE();

        if ( m_socket.bind( m_port, m_host.empty() ? NULL : m_host.c_str() ) == sys::Socket::StatusFailed )
        {
            TRACE_ERROR( "cannot bind to socket (%s:%d), error %d", m_host.c_str(), m_port, sys::General::getLastError() );
            throw BindError;
        }

        if ( m_socket.type() == sys::Socket::Tcp )
        {
            if ( m_socket.listen() == sys::Socket::StatusFailed )
            {
                TRACE_ERROR("socket listen() failed with error %d", sys::Socket::getLastError() );
                throw ListenError;
            }
        }
        

        m_listenerEvent = event_new( base, m_socket.s(), EV_READ | EV_PERSIST, onAcceptStatic,  this );
        
        

        if ( !m_listenerEvent )
        {
            throw GeneralError;
        }

        event_add( m_listenerEvent, NULL );
    }

    Listener::~Listener()
    {
        if ( m_listenerEvent )
        {
            event_free( m_listenerEvent );
        }
    }

    

    void Listener::onAcceptStatic( evutil_socket_t listener, short event, void* arg )
    {
        (( Listener* ) arg)->onAccept();
    }

    BufferedEvent::BufferedEvent( const std::string& host, unsigned int port, const Base& base, bool secure )
    : m_socket( NULL ), m_event( NULL ), m_error( false ), m_input( NULL ), m_output( NULL )
    {
        TRACE( "connecting to %s:%d, ssl: %d", host.c_str(), port, secure );
        
#ifndef _USE_SSL
        if ( secure ) 
        {
            TRACE_ERROR( "openssl support was not built in", "" );
            throw GeneralError;
        }
#else 
        if ( secure )
        {
            
            /* Create a new OpenSSL context */
             SSL_CTX* sslctx = SSL_CTX_new( SSLv23_method() );
             
             if ( !sslctx )
             {
                 TRACE_ERROR( "failed to create openssl context", "" );
                 throw GeneralError;
             }
             
             SSL_CTX_set_verify( sslctx, SSL_VERIFY_NONE, NULL);
             
             SSL* ssl = SSL_new( sslctx );
             
             if ( !ssl )
             {
                 TRACE_ERROR( "failed to create ssl instance", "" );
                 throw GeneralError;
             }
             
             SSL_set_tlsext_host_name( ssl, host.c_str() );
             
             m_event = bufferevent_openssl_socket_new( base, -1, ssl, BUFFEREVENT_SSL_CONNECTING, BEV_OPT_CLOSE_ON_FREE );
             
             bufferevent_openssl_set_allow_dirty_shutdown( m_event, 1 );

        }
#endif
        if ( !m_event )
        {
            m_event = bufferevent_socket_new( base, -1, BEV_OPT_CLOSE_ON_FREE );
        }

      
        if ( !m_event )
        {
            TRACE_ERROR( "failed to create buffered event", "" );
            throw GeneralError;
        }
        
        enable();
        
       
        sys::Socket::Address address( host.c_str() );
        
        address.setPort( port );


        bufferevent_setcb( m_event, onReadStatic, onWriteStatic, onEventStatic, this );
        
        int result = bufferevent_socket_connect( m_event, address, address.length );
        
        
        if ( result == -1 )
        {
            TRACE_ERROR( "failed to connect to %s:%d", host.c_str(), port );
            throw GeneralError;
        }
        else
        {
            m_input = bufferevent_get_input( m_event );
            m_output = bufferevent_get_output( m_event );        
        }
               
    }
    
    BufferedEvent::BufferedEvent( sys::Socket* socket, const Base& base )
    : m_socket( socket ), m_event( NULL ), m_error( false )
    {
        TRACE_ENTERLEAVE();
        General::setSocketNonBlocking( *socket );
        
        
        
        m_event = bufferevent_socket_new( base, *m_socket, 0  );

        if ( !m_event )
        {
            TRACE_ERROR( "failed to create buffered event", "" );
            throw GeneralError;
        }
        
        bufferevent_setcb( m_event, onReadStatic, onWriteStatic, onEventStatic, this );
        
        m_input = bufferevent_get_input( m_event );
        m_output = bufferevent_get_output( m_event );
        
     }

    BufferedEvent::~BufferedEvent()
    {
        TRACE_ENTERLEAVE();
        
        if ( m_event )
        {
            bufferevent_free( m_event );
        }
        
        
        
   }
    
    void BufferedEvent::enable()
    {
        bufferevent_enable( m_event, EV_READ | EV_WRITE  ); 
    }
   
    unsigned int BufferedEvent::read( char* data, unsigned int length ) const
    {
        return bufferevent_read( m_event, data, length );
    }
    
    void BufferedEvent::write( const char* data, unsigned int length ) const
    {
        bufferevent_write( m_event, data, length );
    }
    
    void BufferedEvent::write( evbuffer* buffer ) const
    {
        TRACE_ENTERLEAVE();
        evbuffer_add_buffer( m_output, buffer );
    }
    
    void BufferedEvent::onReadStatic( bufferevent* bev, void* ctx )
    {
        TRACE_ENTERLEAVE();
        (( BufferedEvent* ) ctx)->onRead();
    }

    void BufferedEvent::onWriteStatic( bufferevent* bev, void* ctx )
    {
        TRACE_ENTERLEAVE();
        (( BufferedEvent* ) ctx)->onWrite();
    }

    void BufferedEvent::onEventStatic( bufferevent* bev, short event, void* ctx )
    {
        TRACE_ENTERLEAVE();
        
        (( BufferedEvent* ) ctx)->onEvent( event );
    }
    
    void BufferedEvent::onEvent( short event )
    {
        TRACE_ENTERLEAVE();
        //
        //  invoke callbacks
        //
        if ( event & BEV_EVENT_CONNECTED )
        {
            if ( !m_error )
            {
                onConnect();
            }
            
        }
        
        if ( event & BEV_EVENT_ERROR || event & BEV_EVENT_TIMEOUT || event & BEV_EVENT_EOF )
        {
            if ( !m_error )
            {
                onError();
                m_error = true;
            }
        }
    }

    char* BufferedEvent::readLine() const  
    {
        return evbuffer_readln( m_input, NULL, EVBUFFER_EOL_CRLF );
    }

    unsigned int BufferedEvent::inputLength() const
    {
        return evbuffer_get_length( m_input );
    }
    
    unsigned int BufferedEvent::outputLength() const
    {
        return evbuffer_get_length( m_output );
    }

    int BufferedEvent::searchInput( const char* what, unsigned int length ) const
    {
        evbuffer_ptr found = evbuffer_search( m_input, what, length, NULL );
        return found.pos;
    }

    void BufferedEvent::setTimeouts( unsigned int read, unsigned int write ) const
    {
        TRACE_ENTERLEAVE();

        timeval* readTimeout = NULL;
                
        if ( read )
        {
            readTimeout = new timeval();
            readTimeout->tv_sec = ( long ) read;
            readTimeout->tv_usec = 0;            
        }
        timeval* writeTimeout = NULL;
        
        if ( write )
        {
            writeTimeout = new timeval();
            writeTimeout->tv_sec = ( long ) write;
            writeTimeout->tv_usec = 0;
        }
                
        bufferevent_set_timeouts( m_event, readTimeout, writeTimeout );
        
        if ( readTimeout )
        {
            delete readTimeout;
        }
        
        if ( writeTimeout )
        {
            delete writeTimeout;
        }
    }

    bool BufferedEvent::enabled()
    {
        return bufferevent_get_enabled( m_event ) == 1;
    }
    
    void BufferedEvent::disable()
    {
        if ( m_socket )
        {
            m_socket->shutdown();
        }
        
        bufferevent_disable( m_event, EV_READ | EV_WRITE  );
    }
    
    int BufferedEvent::fd() const
    {
        return ( int ) bufferevent_getfd( m_event );
    }
    
    void Timer::addTimer( unsigned int seconds, void* data, bool once )
    {
        TRACE_ENTERLEAVE();
        
        TRACE("adding timer: seconds %d, data %p, once %d", seconds, data, once );
        
        struct timeval timeout = { seconds, 0 };
        
        Data* timerData = new Data( this );
        
        timerData->arg = data;
        timerData->once = once;
        timerData->seconds = seconds;
        
        
        
        if ( !once )
        {
            timerData->timer = event_new( m_base, -1, EV_PERSIST, onTimerStatic, timerData );
            event_add( timerData->timer, &timeout );
        }
        else
        {
            timerData->timer = evtimer_new( m_base, onTimerStatic, timerData );
            evtimer_add( timerData->timer, &timeout );
        }
    }       
    
    void Timer::onTimerStatic( evutil_socket_t fd, short what, void *arg )
    {
        Data* data = ( Data* )arg;
        data->instance->onTimer( data->seconds, data->arg );
        
        //
        //  delete timer if it was one time
        //
        if ( data->once )
        {
            TRACE("freeing timer", "");

            event_free( data->timer );
            delete data;
        }
    }
    
    Buffer::Buffer()
     : m_free( true ), m_write( false )
    
    {
        TRACE_ENTERLEAVE();
        
        m_buffer = evbuffer_new();
    }
    
    Buffer::Buffer( evbuffer* buffer )
     : m_free( false ), m_buffer( buffer ), m_write( false )
    {
        
    }
    
    Buffer::~Buffer()
    {
        if ( m_free )
        {
            evbuffer_free( m_buffer );
        }
    }
    
    void Buffer::write( const char* data, unsigned int length )
    {
        evbuffer_add( m_buffer, data, length );         
        m_write = true; 
    }
    
    Event::Event( const Base& base, sys::Socket* socket, short flags )
    : m_socket( socket )
    {
        TRACE_ENTERLEAVE();
        TRACE( "socket: %d", socket->s() );
        
        m_event = event_new( base, *socket, flags, onEventStatic, this );
        event_add( m_event, NULL );
    }
    
    Event::~Event()
    {
        TRACE_ENTERLEAVE();
        
        event_free( m_event );
        
        delete m_socket;
    }
    
    void Event::onEventStatic( evutil_socket_t fd, short flags, void* arg )
    {
        TRACE_ENTERLEAVE();
        
        Event* instance = ( Event* ) arg;
        
        if ( flags & EV_WRITE )
        {
            instance->onWrite();
        }
    }
    
    void Event::onRead()
    {
        
    }
    
    void Event::onWrite()
    {
        TRACE_ENTERLEAVE();
    }
    
    
    
    
    
    
    
        
}
