//
//	File: Buffer.h	
//	Dynamic buffer
//	
/*
Copyright 2010 Sergey Zavadski

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
 */

#ifndef _BUFFER_H_
#define _BUFFER_H_

#include "common.h"


//
//	Generic text buffer class
//

class Buffer
{
public:
    Buffer( );
    ~Buffer( );

    //
    //  buffer contents
    //

    const char* contents( ) const
    {
        return m_buffer + m_contentOffset;
    }

    //
    //  buffer length
    //

    unsigned int length( ) const
    {
        return m_contentLength;
    }

    //
    //	append data to message
    //
    void append( const char* buffer, unsigned int length );

    //
    //  get buffer of given length
    //
    char* getBuffer( unsigned int length );
    
    void setBufferLength( unsigned int bufferLength );

    
    //
    //	shrink buffer by given number of bytes
    //
    void shrink( unsigned int offset );

    //
    //	clear contents
    //
    void clear( );

private:
    void reallocate( );

private:
    char* m_buffer;
    //
    //  allocated buffer length
    //
    unsigned int m_bufferLength;
    //
    //  contents size
    //
    unsigned int m_contentLength;
    //
    //  content offset from the beginning of the buffer
    //
    unsigned int m_contentOffset;
    //
    //  chunk length
    //
    unsigned int m_chunkLength;
};


#endif //_BUFFER_H_