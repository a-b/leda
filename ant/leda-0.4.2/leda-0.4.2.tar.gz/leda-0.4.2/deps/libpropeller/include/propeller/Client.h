/*
Copyright 2013-2014 Sergey Zavadski

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

#ifndef _PROPELLER_CLIENT_H_
#define	_PROPELLER_CLIENT_H_

#include "Connection.h"
#include "Buffer.h"


namespace propeller
{
    /**
     * Class that implements multithreaded asynchronous TCP and UDP client functionality and event loop.
     */
    class Client
    {
    public:
        class Thread;
        
        /**
        * Client connection class
        */
        class Connection: public propeller::Connection
        {
            friend class Client;
        public:
            
            virtual ~Connection();
            
            /*
             *  get connection thread
             */
            const Thread& thread() const
            {
                return ( const Thread& ) m_thread;
            }
            

        private:
            virtual void onConnect();
            virtual void onRead();
            
            Connection( const std::string& host, unsigned int port, Thread& thread, bool ssl );
            
            Thread& thread()
            {
                return ( Thread& ) m_thread;
            }
            
            Client& client()
            {
                return thread().client();
            }
            
        private:
            Buffer m_buffer;
        };
   
        
        friend class Connection;
        
        
        /**
         * worker thread class
         */
        class Thread: public EventThread
        {
            friend class Client;
            
        public:
            Thread( Client& client, unsigned int id );
            virtual ~Thread();
            
            


            /**
             * map of established connections
             */
            typedef std::map< const Connection*, const Connection* > ConnectionMap;

            /**
             * all established connections
             * @return map that contains pointers to establised connections
             */
            const ConnectionMap& connections() const 
            {
                return m_connections;
            }

            
            
        private:
            virtual void onStart();
            virtual void onStop();
            
            void onCustomTimer( void* data );
            
            
            void addCustomTimer( unsigned int seconds, bool once, void* data );

            
            
            Client& client()
            {
                return m_client;
            }
            
            void addConnection( const Connection* connection );
            void removeConnection( const Connection* connection );
            
            
        private: 
            Client& m_client;
            ConnectionMap m_connections;
        };
        
        
        class UdpConnection: public libevent::Event
        {
            friend class Client;
            
        
            
            
        private:
            virtual void onWrite();
            UdpConnection( sys::Socket* socket, const Thread& thread );
            void send( const char* data, unsigned int length );
            
            Buffer m_buffer;

        };
        
        
        /**
         *  constructor
         * @param threadCount number of event loop threads
         */
        Client( unsigned int threadCount = 1 );
        virtual ~Client();
        
        /**
         * start the client
         * @param block indicates whether the call should block
         */
        void start( bool block = true );
        /*
         * stop client
         */
        virtual void stop();
        
        
        /**
         * Connect asynchronously via TCP
         * @param port remote port
         * @param host remote host
         * @param threadId thread where to make the connection
         * @param ssl indicates whether to use ssl over the connection 
         * @return new connection object pointer
         */
        Connection* connect( const std::string& host, unsigned  int port, unsigned int threadId = 0, bool ssl = false );
        
        /**
         * add timer
         * @param threadId thread id to add the timer to
         * @param seconds timer timeout in seconds
         * @param data timer data that will be passed  to event handler
         * @param once if true creates one time timer event 
         */
        void addTimer( unsigned int threadId, unsigned int seconds, bool once = true, void* data = NULL );
        /**
         * timer callback
         * @param thread event loop thread where event has occured
         * @param data custom data passed when creating a timer
         */
        virtual void onTimer( const Thread& thread, void* data );
        /**
         * callback that runs when the connection has been established
         * @param connection connection established
         */
        virtual void onConnectionOpened( const Connection& connection );
        /**
         * callback that runs when the connection is closed
         * @param connection  connection closed
         */
        virtual void onConnectionClosed( const Connection& connection );
        
        /**
         * callback that runs when new thread has been started
         * @param thread started thread
         */
        virtual void onThreadStarted( Thread& thread );
        /**
         * callback that runs when thread has been stopped
         * @param thread stopped thread
         */
        virtual void onThreadStopped( const Thread& thread );
        /**
         * data was received on one of the connections
         * @param connection connection reference
         * @param data data received
         * @param length length of data received
         */
        virtual void onData( const Connection& connection, const char* data, unsigned int length );
        
        /**
         * get thread count
         * @return thread count
         */
        unsigned int threadCount() const
        {
            return m_threadCount;
        }
        
        /**
         * send data via UDP
         * @param host address host
         * @param port address port
         * @param data data to send
         * @param length length of data to send
         * @param threadId event loop thread id
         */
        void sendTo( const std::string& host, unsigned int port, const char* data, unsigned int length, unsigned int threadId = 0 );
        
        void join();
        
    private:
        typedef std::map< unsigned int, Thread* > ThreadMap;
        Thread* getThread( unsigned int id );
        
        
    private:
        ThreadMap m_threads;
        bool m_stop;
        unsigned int m_threadCount;
    };
}


#endif	/* _PROPELLER_CLIENT_H_ */

