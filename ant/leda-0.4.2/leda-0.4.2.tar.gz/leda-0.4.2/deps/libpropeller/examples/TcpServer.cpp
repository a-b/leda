//
//  example of a server that sends back data it receives ans sends "hello" to all connections every second
//
#include <propeller/Server.h>

using namespace propeller;

class ExampleTcpServer : public Server
{
public:

    ExampleTcpServer( const std::string& host, unsigned int port )
    : Server( Server::Tcp )
    {
        setHost( host );
        setPort( port );
    }
    
    virtual void onThreadStarted( Thread& thread )
    {
        printf( "started thread  id %d \n", thread.id() );
        
        //
        //  add timer to be repeated every second
        //
        addTimer( 1, thread.id(), false, 0 );
    }
    
    virtual void onThreadStoped( const Thread& thread )
    {
        printf( "stopped thread  id %d \n", thread.id() );
    }
    
    virtual void onConnectionAccepted( const Connection& connection )
    {
        printf( "accepted connection %d from %s \n", connection.id(), connection.address().c_str() );
    }
    
    virtual void onConnectionClosed( const Connection& connection )
    {
        printf( "connection %d closed \n", connection.id() );
    }
    
    virtual void onTimer( const Server::Thread& thread, void* data )
    {
        char hello[] = "hello\n";
        for ( Server::Thread::ConnectionMap::const_iterator i = thread.connections().begin(); i != thread.connections().end(); i++ )
        {
            Server::Connection* connection = ( Server::Connection* ) i->first;
            connection->write( hello, sizeof( hello ) );
        }
    }
    
    
    virtual void onDataReceived( const Connection& connection, const char* data, unsigned int length )
    {
        //
        //  send back data received
        //
        connection.write( data, length );
    }

    
};

int main( int argv, char** argc )
{
    std::string host = "localhost";
    unsigned int port = 10000;
    
    //
    //  create server instance
    //
    ExampleTcpServer server( host, port );
    //
    //  start the server
    //
    printf( "starting server on %s:%d\n", host.c_str(), port );
    server.start( );
}



