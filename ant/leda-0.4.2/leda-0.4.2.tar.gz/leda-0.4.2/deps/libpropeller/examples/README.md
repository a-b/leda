This is the examples.

To build the examples run
        
        make examples
        
from the top level directory        
        