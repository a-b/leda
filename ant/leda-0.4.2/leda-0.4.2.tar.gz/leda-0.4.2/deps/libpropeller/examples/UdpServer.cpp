//
//  example of a UDP server 
//
#include <propeller/Server.h>

using namespace propeller;

class ExampleUdpServer : public Server
{
public:

    ExampleUdpServer( const std::string& host, unsigned int port )
    : Server( Server::Udp )
    {
        setHost( host );
        setPort( port );
    }
    
    virtual void onThreadStarted( Thread& thread )
    {
        printf( "started thread  id %d \n", thread.id() );
    }
    
    virtual void onThreadStoped( const Thread& thread )
    {
        printf( "stopped thread  id %d \n", thread.id() );
    }
    
    virtual void onDataReceived( const Server::Thread& thread, const std::string& from, const char* data, unsigned int length )
    { 
        printf( "received %d bytes from %s \n", length, from.c_str() );
    }
    
};

int main( int argv, char** argc )
{
    std::string host = "localhost";
    unsigned int port = 10000;
    
    //
    //  create server instance
    //
    ExampleUdpServer server( host, port );
    //
    //  start the server
    //
    printf( "starting server on %s:%d\n", host.c_str(), port );
    server.start( );
}



