//
//  example of a HTTP server that sends string "hello wolrd!" in response to every request
//

#include <propeller/HttpServer.h>

using namespace propeller;

class ExampleHttpServer : public http::Server
{
public:

    ExampleHttpServer( const std::string& host, unsigned int port )
    {
        setPort( port );
        setHost( host );
        
    }
    virtual void onRequest( const http::Request& request, http::Response& response, const Server::Thread& thread )
    {
        //
        //  return this text for every response
        //
        response.setBody( "hello world!" );
    }
};

int main( int argv, char** argc )
{
    std::string host = "localhost";
    unsigned int port = 8080;
    //
    //  create http server instance
    //
    ExampleHttpServer server( host, port );
    printf( "starting server on %s:%d \n", host.c_str(), port );
    
    //
    //  start the server
    //
    server.start( );
}



