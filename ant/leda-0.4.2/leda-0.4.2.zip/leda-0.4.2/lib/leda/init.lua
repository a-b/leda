-- lua std lib
require 'std'
-- middleclass
require 'middleclass'

-- reference storage global table
__leda = __leda or {} 

