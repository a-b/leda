//
//  libpropelller integration test that tests general functionality
//
#include "Client.h"
#include "Server.h"
#include "HttpServer.h"
#include <assert.h>
#include <time.h>  

using namespace propeller;


std::string testString = "test";

char hostname [] = "localhost";

static bool g_clientTimer = false;
static bool g_serverEcho = false;
static bool g_serverTimer = false;
static bool g_serverHttp = false;
static bool g_serverUdp = false;



class TestServer: public Server
{
public:
    TestServer( unsigned int port, Server::Type type = Server::Tcp )
    : Server( type )
    {
        setThreadCount( 2 );
        setHost( hostname );
        setPort( port );
    }
};

class TestTcpServer : public TestServer
{
public:
    TestTcpServer( unsigned int port )
    : TestServer( port )
    {
        
    }
    
    virtual void onThreadStarted( Server::Thread& thread ) 
    {
        this->addTimer( 1, thread.id(), false, 0 );
    }
    
    virtual void onTimer( const Server::Thread& thread, void* data )
    {
        for ( Server::Thread::ConnectionMap::const_iterator i = thread.connections().begin(); i != thread.connections().end(); i++ )
        {
            Server::Connection* connection = ( Server::Connection* ) i->first;
            connection->write( testString.c_str(), testString.size() );
            
        }
    }
    
    virtual void onDataReceived( const Connection& connection, const char* data, unsigned int length )
    {
        connection.write( data, length );
    }
};

class TestClient: public Client
{   public:
        TestClient( unsigned int portTcp, unsigned int  portHttp, unsigned int portUdp )
        : Client( 1 ), m_portTcp( portTcp ), m_portHttp( portHttp ), m_echo( NULL ), m_timer( NULL ), m_portUdp( portUdp )
        {
            m_echoString = "echo";
        }
        
        virtual void onThreadStarted( Client::Thread& thread )
        {
            
            m_echo = connect( hostname, m_portTcp );
            assert( m_echo );
            
            m_timer = connect( hostname, m_portTcp );
            assert( m_timer );
            
            m_http = connect( hostname, m_portHttp ); 
            assert( m_http );
            
            addTimer( thread.id(), 2, false );
            sendTo( hostname, m_portUdp, testString.c_str(), testString.size() ); 
            
        }
        
        virtual void onConnectionOpened( const Client::Connection& connection )
        {
            if ( &connection == m_echo )
            {
                connection.write( m_echoString.c_str(), m_echoString.size() );
            }
            
            if ( &connection == m_http )
            {
                std::string request = "GET / HTTP/1.1\r\n\r\n\r\n";
                
                connection.write( request.c_str(), request.size() );
            }
        }
        
        virtual void onData( const Connection& connection, const char* data, unsigned int length )
        {
            std::string receivedText;
            receivedText.append( data, length );
           
            if ( &connection == m_echo && !m_echoString.empty() )
            {
                assert( receivedText.find( m_echoString ) != std::string::npos );
                m_echoString = "";
                g_serverEcho = true;
            }
            
            if ( &connection == m_timer )
            {
                assert( receivedText.find( testString ) != std::string::npos );
                g_serverTimer = true;
            }
            
            if ( &connection == m_http )
            {
                std::string response = "HTTP/1.1 200 OK\r\n";
                assert( receivedText.find( response ) != std::string::npos );
                g_serverHttp = true;
            }
        }
        
        virtual void onTimer( const Client::Thread& thread, void* data )
        {
            assert( m_echoString.empty() );
            g_clientTimer = true;
        }
        
        
    private:
        unsigned int m_portTcp;
        unsigned int m_portHttp;
        unsigned int m_portUdp;
        
        Client::Connection* m_echo;
        Client::Connection* m_timer;
        Client::Connection* m_http;
        std::string m_echoString;
};
//
//
class TestHttpServer: public http::Server
{
public:
    TestHttpServer( unsigned int port )
    : http::Server()
    {
        setPort( port );
        setHost( hostname );
    }
    
    virtual void onRequest( const http::Request& request, http::Response& response, const Server::Thread& thread )
    {
        response.setBody( testString.c_str(), testString.size() );
    }
};

class TestUdpServer: public TestServer
{
public:
    TestUdpServer( unsigned int port )
    : TestServer( port, Server::Udp )
    {
    }
    
    virtual void onDataReceived(  const Thread& thread, const std::string& address, const char* data, unsigned int length )
    {
        std::string receivedText;
        receivedText.append( data, length );
        assert( receivedText == testString );
        g_serverUdp = true;
        
        
        
    }
};

class ServerThread: public sys::Thread
{
public:
    ServerThread( Server* server )
    :  m_server( server )
    {
        
    }
private:
    virtual void routine()
    {
        m_server->start();
    }
    
private:
    Server* m_server;
    
};



int main(int argx, char** argv)
{
    
    srand (time(NULL));
     
    unsigned int port = 10000 + rand() % 100;
    
    unsigned int httpPort = port + 500;
    unsigned int udpPort = port + 1000;
    unsigned int timeout = 0;
    
    
    ( new ServerThread( new TestTcpServer( port ) ) )->start();
    ( new ServerThread( new TestHttpServer( httpPort ) ) )->start();
    ( new ServerThread( new TestUdpServer( udpPort ) ) )->start();
    
    sleep( 1 );
    
    TestClient* client = new TestClient( port, httpPort, udpPort );
    client->start( false );
    
    
    while ( timeout < 10 )
    {
        sleep( 1 );
        timeout += 1;
        
    }
    
    assert( g_clientTimer );
    assert( g_serverEcho );  
    assert( g_serverTimer );
    assert( g_serverHttp );
    assert( g_serverUdp );
    
    
    fprintf( stderr, "all tests passed \n" );

    return 0;
}
