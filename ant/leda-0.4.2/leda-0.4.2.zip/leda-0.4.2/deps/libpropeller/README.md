libpropeller
============

Multithreaded class library in C++ for building high performance network applications powered by libevent. All network operations are asynchronous and executed concurrently multiple libevent event loops. It offers easy to integrate classes that encapsulate functionality of a HTTP server,  TCP and UDP server, asynchronous client. 


For api documentation see [documentation](http://sergeyzavadski.github.io/libpropeller/)

For usage examples see [examples](https://github.com/sergeyzavadski/libpropeller/tree/master/examples)

to build examples run

        make examples
        

        





    
    
    

