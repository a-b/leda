/*
Copyright 2013-2014 Sergey Zavadski

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

#include "Client.h"

#include "trace.h"

namespace propeller
{    
    Client::Thread::Thread( Client& client, unsigned int id )
    : m_client( client ), EventThread( id )
    {
        TRACE_ENTERLEAVE();
        
        TRACE( "creating thread with id %d", id );
    }
    
    Client::Thread::~Thread()
    {
        TRACE_ENTERLEAVE();
        while ( !m_connections.empty() )
        {
            delete m_connections.begin()->second;
        }
    }
    
    void Client::Thread::addConnection( const Connection* connection )
    {
        TRACE_ENTERLEAVE();
        
        client().onConnectionOpened( *connection );
        m_connections[ connection ] = connection;
    }
    
    void Client::Thread::removeConnection( const Connection* connection )
    {
        TRACE_ENTERLEAVE();
        
        client().onConnectionClosed( *connection );
        m_connections.erase( connection );
    }
    
    void Client::Thread::onStart()
    {
        TRACE_ENTERLEAVE();
        //
        //  invoke client start callback
        //
        m_client.onThreadStarted( *this );
    }
    
    void Client::Thread::onStop()
    {
        TRACE_ENTERLEAVE();
        //
        //  invoke client stop callback
        //
        m_client.onThreadStopped( *this );
    }
    
    void Client::Thread::addCustomTimer( unsigned int seconds, bool once, void* data )
    {
        TRACE_ENTERLEAVE();
        
        addTimerHandler( ( EventThread::TimerHandler ) &Thread::onCustomTimer, seconds, once, data );
    }
    
    void Client::Thread::onCustomTimer( void * data )
    {
        TRACE_ENTERLEAVE();
        //
        //  invoke client timer callback
        //
        m_client.onTimer( *this, data );
    }

    Client::Connection::Connection( const std::string& host, unsigned int port, Thread& thread, bool ssl )
    : propeller::Connection( host, port, ( EventThread& ) thread, ssl )
    {
        
    }
    //
    //  connection connect callback
    //
    void Client::Connection::onConnect()
    {
        TRACE_ENTERLEAVE();
        
        thread().addConnection( this );
    }
    
    
    Client::Connection::~Connection()
    {
        TRACE_ENTERLEAVE();
        thread().removeConnection( this );
    }
    
    void Client::Connection::onRead()
    {
        TRACE_ENTERLEAVE();
        
        unsigned int length = inputLength();
        char* buffer = m_buffer.getBuffer( length );
        
        unsigned int readLength = read( buffer, length );
        
        client().onData( *this, buffer, readLength );
        m_buffer.shrink( length );
    }
  
    Client::Connection* Client::connect( const std::string& host, unsigned  int port, unsigned int threadId, bool ssl )
    {
        TRACE_ENTERLEAVE();
        
        //
        //  create new connection to provided host and port
        //
        Thread* thread = getThread( threadId );
        Connection* connection = NULL;
        if ( thread )
        {
            try
            {
                connection = new Connection( host, port, *thread , ssl );
            }
            catch ( libevent::Error e )
            {
                
            }
         }
              
        return connection;
    }
    
    void Client::start( bool block )
    {
        TRACE_ENTERLEAVE();
        
        //
        //  start worker threads
        //  
        unsigned int id = 0;
        
        TRACE( "starting %d threads", m_threadCount );
        while( m_threads.size() < m_threadCount )
        {
            Thread* thread = new Thread( *this, id );
            m_threads[ id ] = thread;
            id ++;
            thread->start();
        }
        
        if ( block )
        {
            join();
        }

    }
    
    Client::Client( unsigned int threadCount )
    :  m_stop( false ), m_threadCount( threadCount )
    {
        TRACE_ENTERLEAVE();
        
        libevent::General::init();
        
    }
    
    Client::~Client()
    {
        
        TRACE_ENTERLEAVE();
        stop();
        
        while ( !m_threads.empty() )
        {
            ThreadMap::iterator i = m_threads.begin();
            delete i->second;
            m_threads.erase( i );
        }
        
    }
    
    void Client::onThreadStarted( Thread& thread )
    {
        TRACE_ENTERLEAVE();
    }
    
    void Client::onThreadStopped( const Thread& thread )
    {
        TRACE_ENTERLEAVE();
    }
    
    Client::Thread* Client::getThread( unsigned int id )
    {
        ThreadMap::const_iterator found = m_threads.find( id );
        
        if ( found != m_threads.end() )
        {
            return found->second;
        }
        else
        {
            TRACE( "thread with id %d not found", id );
        }
        
        return NULL;
    }
    
    void Client::addTimer( unsigned int threadId, unsigned int seconds, bool once, void* data )
    {
        TRACE_ENTERLEAVE();
        
        TRACE( "thread id: %d, seconds: %d, once: %d", threadId, seconds, once );
        
        Thread* thread = getThread( threadId );
        if ( thread )
        {
            thread->addCustomTimer( seconds, once, data );
        }
        
        
    }
    
    
    
    void Client::onConnectionOpened( const Connection& connection )
    {
        TRACE_ENTERLEAVE();
    }
    
    void Client::onConnectionClosed( const Connection& connection )
    {
        TRACE_ENTERLEAVE();
    }
    
    void Client::onTimer( const Thread& thread, void* data )
    {
        TRACE_ENTERLEAVE();
    }
    
    void Client::join()
    {
        TRACE_ENTERLEAVE();
        m_threads.begin()->second->join();
    }

    void Client::stop()
    {
        if ( !m_stop )
        {
            for ( ThreadMap::iterator i = m_threads.begin(); i != m_threads.end();  i++ )
            {
                i->second->stop();
            }
            
            
        }
    }
    
    void Client::onData( const Connection& connection, const char* data, unsigned int length )
    {
        TRACE_ENTERLEAVE();
    }
    
    Client::UdpConnection::UdpConnection( sys::Socket* socket, const Thread& thread )
    : Event( thread.base(), socket, EV_WRITE )
    {
        
    }
    
    void Client::UdpConnection::send( const char* data, unsigned int length )
    {
        m_buffer.append( data, length );
        TRACE( "buffer length: %d", m_buffer.length() );
        
    }
    
    void Client::UdpConnection::onWrite()
    {
        TRACE_ENTERLEAVE();
        
        if ( m_buffer.length() )
        {
            unsigned int bytesSent = 0;
            m_socket->sendto( m_buffer.contents(), m_buffer.length(), bytesSent );
            
            TRACE( "bytes sent: %d", bytesSent );
            
            m_buffer.shrink( bytesSent );
        }
        
        if ( m_buffer.length() == 0 )
        {
            delete this;
        }
        
        
        
    }
    
    
    void Client::sendTo( const std::string& host, unsigned int port, const char* data, unsigned int length, unsigned int threadId )
    {
        TRACE_ENTERLEAVE();
        
        TRACE(" send to %s:%d",  host.c_str(), port );
        
        Thread* thread = getThread( threadId );
        
        if ( !thread )
        {
            return;
        }
        
        UdpConnection* udp = new UdpConnection( new sys::Socket( host, port, sys::Socket::Udp ), *thread );
        udp->send( data, length );
        
        
        
    }
    

}
    