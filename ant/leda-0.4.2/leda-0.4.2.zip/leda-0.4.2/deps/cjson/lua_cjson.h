
#ifndef _LUA_CJSON_H
#define	_LUA_CJSON_H
#include <lua.h>



#ifdef __cplusplus
extern "C"
{
#endif

extern int luaopen_cjson(lua_State* l);

#ifdef __cplusplus
}
#endif

#endif	/* _LUA_CJSON_H */

